package atividade1;
/**
 *
 * @author Maria
 */
import java.util.Scanner;

public class Menu {
    public static void main(String args[]){
        Scanner ler = new Scanner(System.in);
        
        int escolha = 0;
        Pessoa p = new Pessoa();
        
        while(escolha != 3){
            
            System.out.println("\nSistema de gestão de pessoas");
            System.out.println("------------------------");
            System.out.println("Menu:");
            System.out.println("1 - Criar Pessoa");
            System.out.println("2 - Mostrar Pessoa");
            System.out.println("3 - Sair");
            System.out.println("Digite o número desejado!");
            escolha = ler.nextInt();
            
            switch(escolha){
                case 1:{
                    System.out.println("Digite o CPF:");
                    p.setCpf(ler.next());
                    System.out.println("Digite o nome:");
                    p.setNome(ler.next());
                    
                    while(p.getSexo() != 'M' && p.getSexo() != 'F'){
                        System.out.println("Digite o Sexo(M ou F):");
                        p.setSexo(ler.next().charAt(0));
                        
                        if(p.getSexo() != 'M' && p.getSexo() != 'F'){
                            System.out.println("Caracter digitado é inválido!");
                        }
                    }
                    System.out.println("Digite a idade:");
                    p.setIdade(ler.nextInt());
                }
                    
                case 2: {
                    System.out.println("------------------------");
                    p.imprimirPessoa(p);
                    System.out.println("------------------------\n");
                }
                    
                case 3:
                    System.out.println("Programa encerrado!");
                    
                default:
                    System.out.println("Número digitado é inválido!");
            }
            
            if(escolha == 3){
                break;
            }
        }
    }
}