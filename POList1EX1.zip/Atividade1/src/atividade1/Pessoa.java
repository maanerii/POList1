package atividade1;

/**
 *
 * @author Maria
 */
public class Pessoa {
    private String cpf;
    private String nome;
    private char sexo;
    private int idade;
 
    public void setCpf(String cpf){
        this.cpf = cpf;
    }
    
    public String getCpf(){
        return this.cpf;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public void setSexo(char sexo){
        this.sexo = sexo;
    }
    
    public char getSexo(){
        return this.sexo;
    }
    
    public void setIdade(int idade){
        this.idade = idade;
    }
    
    public int getIdade(){
        return this.idade;
    }
    
   public void imprimirPessoa(Pessoa p){
        System.out.printf("CPF: %s\n", p.getCpf());
        System.out.printf("Nome: %s\n", p.getNome());
        System.out.printf("Sexo: %c\n", p.getSexo());
        System.out.printf("Idade: %d\n", p.getIdade());
   }

    
    }


